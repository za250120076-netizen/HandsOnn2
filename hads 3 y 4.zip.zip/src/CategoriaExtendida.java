public class CategoriaExtendida extends Categoria {

    private double puntoMedio;
    private int faAc;         // frecuencia absoluta acumulada
    private double frAc;      // frecuencia relativa acumulada

    public CategoriaExtendida(double li, double ls) {
        super(li, ls);
        this.puntoMedio = (li + ls) / 2.0;
    }

    public double getPuntoMedio() { return puntoMedio; }
    public int getFaAc() { return faAc; }
    public double getFrAc() { return frAc; }

    public void setFaAc(int faAc) { this.faAc = faAc; }
    public void setFrAc(double frAc) { this.frAc = frAc; }
}
