import java.util.ArrayList;
import java.util.Arrays;

public class TablaFrecuencias {

    private ArrayList<Categoria> tablaHO3;
    private ArrayList<Categoria> tablaHO4;

    private double[] data;   // para HO4

    public TablaFrecuencias(String[] nombres, int[] frecuencias, double[] dataHO4) {

        construirHO3(nombres, frecuencias);
        this.data = dataHO4;
        construirHO4();
    }

    // ==========================================
    //              HANDS-ON 3
    // ==========================================
    private void construirHO3(String[] nombres, int[] frecuencias) {
        tablaHO3 = new ArrayList<>();

        int total = 0;
        for (int f : frecuencias) total += f;

        for (int i = 0; i < nombres.length; i++) {
            tablaHO3.add(new Categoria(nombres[i], frecuencias[i], total));
        }
    }

    public void imprimirHO3() {
        System.out.println("\n===== TABLA DE FRECUENCIAS (HANDS-ON 3) =====");
        System.out.printf("%-10s %-5s %-5s %-5s\n", "MT", "f", "fr", "%");

        int total = 0;

        for (Categoria c : tablaHO3) {
            System.out.printf("%-10s %-5d %-5.2f %-5.0f%%\n",
                    c.getNombre(), c.getFa(), c.getFr(), c.getPorcentaje());
            total += c.getFa();
        }

        System.out.println("---------------------------------------------");
        System.out.printf("%-10s %-5d %-5.2f %-5.0f%%\n", "TOTAL", total, 1.00, 100.0);
    }

    // ==========================================
    //              HANDS-ON 4
    // ==========================================
    private void construirHO4() {

        tablaHO4 = new ArrayList<>();

        Arrays.sort(data);
        int n = data.length;

        double min = data[0];
        double max = data[n - 1];
        double rango = max - min;

        int k = (int) Math.ceil(1 + 3.322 * Math.log10(n));
        double amplitud = Math.ceil(rango / k);

        double li = min;

        for (int i = 0; i < k; i++) {
            double ls = li + amplitud;
            tablaHO4.add(new Categoria(li, ls));
            li = ls;
        }

        for (double valor : data) {
            for (Categoria c : tablaHO4) {
                if ((valor >= c.getLi() && valor < c.getLs()) || valor == max) {
                    c.incrementarFA();
                    break;
                }
            }
        }

        int faAc = 0;
        double frAc = 0;

        for (Categoria c : tablaHO4) {
            double fr = (double) c.getFa() / n;
            c.setFr(fr);

            faAc += c.getFa();
            frAc += fr;

            c.setFaAc(faAc);
            c.setFrAc(frAc);
        }
    }

    public void imprimirHO4() {
        System.out.println("\n===== TABLA EXTENDIDA (HANDS-ON 4) =====");
        System.out.printf("%-15s %-5s %-5s %-5s %-8s %-8s %-8s\n",
                "Clase", "f", "fr", "%", "FA Ac", "FR Ac", "PM");

        for (Categoria c : tablaHO4) {
            System.out.printf("%6.2f-%-6.2f %-5d %-5.2f %-5.0f%% %-8d %-8.2f %-8.2f\n",
                    c.getLi(), c.getLs(), c.getFa(), c.getFr(), c.getPorcentaje(),
                    c.getFaAc(), c.getFrAc(), c.getPuntoMedio());
        }
    }
}
